import XCTest

import jeuTests

var tests = [XCTestCaseEntry]()
tests += jeuTests.allTests()
XCTMain(tests)