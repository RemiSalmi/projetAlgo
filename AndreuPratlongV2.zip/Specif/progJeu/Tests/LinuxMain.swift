import XCTest

import progJeuTests

var tests = [XCTestCaseEntry]()
tests += progJeuTests.allTests()
XCTMain(tests)