* le package jeu est une librairie comportant tous les protocoles
* le package progJeu est un executable (Le jeu lui même)
* le package test est une librairie comportant toutes les fonctions de test
* le package progTest est un executable (des fonctions de test)
** Bon courage :) **
